"""ipd_registration URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.showipd_registration,name='showipd_registration'),
    path('Insertipd_registration', views.Insertipd_registration,name='Insertipd_registration'),
    path('Edit/<int:id>', views.Editipd_registration,name='Editipd_registration'),
    path('Update/<int:id>', views.updateempipd_registration,name='updateempipd_registration'),
    path('Delete/<int:id>', views.Delempipd_registration,name='Delempipd_registration'),
]
